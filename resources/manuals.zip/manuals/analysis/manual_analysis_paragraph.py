import os

path ="/home/shawn/Desktop/ConfAnalysis/manuals/result/afterMerge/manual"
files = os.listdir(path)
apps = ["cinder","glance","nova","placement","neutron","keystone"]
'''
1. get conf list from Teng's work
2. define intra-component conf denpendency analysis
3. define inter-component conf dependency analysis. quite similar with 2.Just chagne the scope of pair conf
'''

def get_paras(lines):
	i = 0
	j = 0
	para = ""
	paras = []
	while j < len(lines):
		if lines[j]=="\n" or lines[j]=="" :
			if para <> "":
				paras.append(para)
				para = ""
				i = j+1
				j = j+1
			else:
				j= j+1
		else:
			para = para+lines[j][:-1]
			j = j+1
	# print(paras)
	if para <> "":
		paras.append(para)
	# for n in range(i,len(lines)):
	# 	para = para+lines[n][:-1]
	# 	paras.append(para)
	return paras
def get_app_list(app):
	f = open("ConfList/"+app,"r")
	content = f.read()
	params = content.split("##")
	return params
# currently just name. No section name
def intra_component_extraction(app):
	res = open("intra_component/paragraph/"+app+"_with_paragraph","a")
	result = []
	params = get_app_list(app)
	counter = 0
	situation = [0,0,0,0]
	situation2 = [0,0,0,0]
	for file in files:
		counter = counter+1
		f = open(path+"/"+file,"r")
		content = f.readlines()
		paras = get_paras(content)
		for para in paras:
			para = para.replace("\n"," ")
			para_split = para.split()
			if para =="\n" or para=="" or len(para_split)<10:
				continue
			for index1 in range(len(params)):
				for index2 in range(len(params)):
					if index1==0 or index2 ==0:# do not know whether this will work
						continue
					if index1>=index2:
						continue
					else:
						value1 = params[index1].split("**")
						value2 = params[index2].split("**")
						# if value1[4] == "1\n\r":
						# 	value1[4] = "1"
						# elif value1[4] == "0\n\r":
						# 	value1[4] = 0
						# if value2[4] == "1\n\r":
						# 	value2[4] = "1"
						# elif value2[4] == "0\n\r":
						# 	value2[4] = 0
						# value1[4] = value1[4].replace("\n\r","")
						# value2[4] = value2[4].replace("\n\r","")
						print(index1,index2,counter,len(value1),len(value2))
						# print(value1)
						# print(value2)
						# if len(value1) <5 or len(value2)<5:
						# 	continue
						if int(value1[-1][0]) ==1 and int(value2[-1][0]) ==1:
							situation[0] = situation[0]+1
							if value1[0] in para_split and value2[0] in para_split:
								situation2[0] = situation2[0]+1
								result.append(file +" " +value1[-2] +" " + value1[0] + " " + value2[-2] +" " + value2[0] +"\n") 
						elif int(value1[-1][0]) ==1 and int(value2[-1][0]) ==0:
							situation[1] = situation[1]+1
							if value1[0] in para_split and value2[0] in para_split and value2[3] in para_split:
								situation2[1] = situation2[1]+1
								result.append(file +" " +value1[0] + " " + value2[-2] +" " + value2[0] +"\n") 
						elif int(value1[-1][0]) ==0 and int(value2[-1][0]) ==1:
							situation[2] = situation[2]+1
							if value1[0] in para_split and value2[0] in para_split and value1[3] in para_split:
								situation2[2] = situation2[2]+1
								result.append(file +" " +value1[-2] +" " + value1[0] + " " + value2[0] +"\n")
						elif int(value1[-1][0]) ==0 and int(value2[-1][0]) ==0:
							situation[3] = situation[3]+1
							if value1[0] in para_split and value2[0] in para_split and value2[3] in para_split and value1[3] in para_split:
								situation2[3] = situation2[3]+1
								result.append(file +" " +value1[0] + " " + value2[0] +"\n") 
						# print(situation)
						print(situation2)
						# print(para)
	result = list(set(result))
	for line in result:
		res.write(line)
	res.close()

intra_component_extraction("cinder")
intra_component_extraction("glance")
intra_component_extraction("nova")



# below is test code for para splitor
# f = open(path+"/cinder-latest-admin-blockstorage-backup-disks","r")
# f = open("test","r")
# content = f.readlines()
# paras = get_paras(content)
# for para in paras:
# 	print(para)