## Formatting of the files: the infos of every configuration parameter has 4 '**' to separate the 5 fields of a parameter shown as below:
- name
- default value
- description
- section name
- is Single name (1 is short for single, while 0 is short for NOT single)

##eg: ##ParameterA**False**This is a parameter for test**default**1

