import json

apps = ["cinder","nova","neutron","keystone","placement","glance"]
urls = []
urls_all= []
for app in apps:
	with open("../"+app+"/urls.json",'r') as load_f:
		urls = json.load(load_f)
	urls_all.extend(urls)
	urls_all = list(set(urls_all))

with open("urls_all.json",'w') as f:
	urls = json.dump(urls_all,f)
