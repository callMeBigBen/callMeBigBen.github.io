import os
import re
import json
import urllib2
import random
from bs4 import BeautifulSoup


	
# def read_urls():
# 	with open("../../result/nova/urls.json",'r') as load_f:
# 		url_list = json.load(load_f)
# 	return url_list

urls = []
with open("../../result/cinder/urls.json",'r') as load_f:
	urls = json.load(load_f)
link = "https://docs.openstack.org/cinder/stein/index.html"

my_headers = [
    {"User-Agent" : "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36"},
    {"User-Agent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36"},
    {"User-Agent" : "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0"},
    {"User-Agent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/537.75.14"},
    {"User-Agent" : "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Win64; x64; Trident/6.0)"},
    {"User-Agent" : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; it; rv:1.8.1.11) Gecko/20071127 Firefox/2.0.0.11'},
    {"User-Agent" : 'Opera/9.25 (Windows NT 5.1; U; en)'},
    {"User-Agent" : 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)'},
    {"User-Agent" : 'Mozilla/5.0 (compatible; Konqueror/3.5; Linux) KHTML/3.5.5 (like Gecko) (Kubuntu)'},
    {"User-Agent" : 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.12) Gecko/20070731 Ubuntu/dapper-security Firefox/1.5.0.12'},
    {"User-Agent" : 'Lynx/2.8.5rel.1 libwww-FM/2.14 SSL-MM/1.4.1 GNUTLS/1.2.9'},
    {"User-Agent" : "Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.7 (KHTML, like Gecko) Ubuntu/11.04 Chromium/16.0.912.77 Chrome/16.0.912.77 Safari/535.7"},
    {"User-Agent" : "Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:10.0) Gecko/20100101 Firefox/10.0 "}
]

def parse_url(url,base):
	if "#" not in url:
		# if "https" not in a["href"] or "http" not in a["href"] :
		# # content_url.append(base+a["href"])
		# 	if str(base+a["href"]) not in urls:
		# 		urls.append(base+a["href"])
		# 		urls =crawl(urls,base,base+a["href"],str(counter))
		if "placeholder" in url or "api" in url or url[-1]=="/" or "file:" in url or "mailto" in url or ".html" not in url:
			return None
		elif "https" in url or "http" in url:	
			if "docs.openstack.org" in url:
				return url
		else:
			return str(base+url)

def crawl(urls,link):
	base = link[0:link.rfind("/")+1]
	print(link)
	tmpHeader = random.choice(my_headers)
	req =	urllib2.Request(link, headers=tmpHeader)
	page = urllib2.urlopen(req)
	f = open("../../result/cinder/manual/"+link[link.find(".org")+5:link.rfind(".html")].replace("/","-"),'w')
	content= page.read()
	content= BeautifulSoup(content,'html.parser')
	content_text = content.find_all('div')[19].get_text().encode('utf-8')
	# content_text= content_body[content_body.find():]
	# for sib in content_body:
	# 	content_text = content_text+sib.get_text()
	f.write(content_text)
	f.close()
	# print(len(content.find_all('div')))
	content_div = content.find_all('div')[19]# 19 is the main section
	# index=0
	# for div in content_div:
	# 	print(index,div.attrs)
	# 	index = index+1

	# find li
	content_li = []
	for ul in content_div.find_all('ul'):
		for li in ul.find_all('li'):
			content_li.append(li)
	# print("len of li:",len(content_li))

	# extract url
	# content_url = []
	if len(content_li)<2:
		return urls
	for url in content_li:
		a=url.find("a")
		if a is not None:
			if a["href"] is not None:
				# print(a["href"])
				 u = parse_url(a["href"],base)
				 if u is not None and u not in urls:
				 	urls.append(u)
				 	urls = crawl(urls,u)
						# print(a["href"])
		# except:
		# 	print "exception happens when extracting URL"

	# content_url = list(set(content_url))
	print(len(urls))
	return urls


urls = crawl(urls,link)
# urls=crawl(read_urls())
with open("../../result/cinder/urls.json",'w') as f:
	json.dump(urls,f)



