import os

path ="/home/shawn/Desktop/ConfAnalysis/manuals/result/afterMerge/manual"
files = os.listdir(path)
apps = ["cinder","glance","nova","placement","neutron","keystone"]
'''
1. get conf list from Teng's work
2. define intra-component conf denpendency analysis
3. define inter-component conf dependency analysis. quite similar with 2.Just chagne the scope of pair conf
'''
def get_app_list(app):
	f = open("ConfList/"+app,"r")
	content = f.read()
	params = content.split("##")
	return params
# currently just name. No section name
def intra_component_extraction(app):
	res = open("intra_component/page/"+app,"w")
	result = []
	params = get_app_list(app)
	print(app," has ",len(params)," params.")
	print(len(files)," files")
	counter = 0
	for file in files:
		f = open(path+"/"+file,"r")
		content = f.read()
		content = content.replace("\n","")
		ontent = content.replace("\r","")
		content_split = content.split()
		for index1 in range(len(params)):
			for index2 in range(len(params)):
				if index1==0 or index2 ==0:
					continue
				if index1>= index2:# do not know whether this will work
					continue
				else:
					value1 = params[index1].split("**")
					value2 = params[index2].split("**")
					print(index1,index2)
					if value1[0] in content_split and value2[0] in content_split:
						result.append(value1[3] +" " + value1[0] + " " + value2[3] +" " + value2[0] +"\n")
						counter  = counter +1
				print(counter)
	result = list(set(result))
	for line in result:
		res.write(line)
	res.close()

intra_component_extraction("cinder")
intra_component_extraction("glance")
intra_component_extraction("nova")