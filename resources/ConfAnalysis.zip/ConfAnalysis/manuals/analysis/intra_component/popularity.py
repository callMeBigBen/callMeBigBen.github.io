popularity = {}

f = open("nova","r")
lines = f.readlines()
for line in lines:
	values = line.split()
	if values[1] not in popularity:
		popularity[values[1]] = 1
	else:
		popularity[values[1]] = popularity[values[1]] + 1
	if values[3] not in popularity:
		popularity[values[3]] = 1
	else:
		popularity[values[3]] = popularity[values[3]] + 1
popularity = sorted(popularity.items(),key = lambda item:item[1],reverse = True)
# print(popularity)
g = open("popularity","w")
for p in popularity:
	g.write(p[0]+": "+str(p[1])+"\n")
g.close()