import json
import gensim
import os
import re
import smart_open
import random
import collections
import math
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import numpy as numpy
#Qingrong's format is name**desc**default
#My format is name**type**default value**desc
black_list=['enable','debug','connection','user','enabled']
applications=['cinder','glance','keystone','neutron','nova','placement']
def readin(filename):
	my_dict={}
	with open(filename) as f:
		my_dict = json.load(f)
	return my_dict
# to get the parameter name list.Return a 2-dim list
def get_configuration_parameter():
	config_list={}
	for app in applications:
		config_list[app]=[]
		f=open('../configuration_files/'+app+"/"+app+"_configuration",'r')
		for line in f:
			line=line.split("**")
			config_list[app].append(line[0].lower())
	return config_list
# to get the parameter name and description list. Return a dict{name:desc}
def get_configuration_content():
	config_content={}
	for app in applications:
		print app
		config_content[app]=[]
		f=open('../configuration_files/'+app+"/"+app+"_configuration",'r')
		for line in f:
			line=line.split("**")
			config_content[app].append((line[0].lower(),line[3].lower()))
	return config_content
# a function iterator. every call returns the next index of substring
def find_all_index(string,substring):
	return [m.start() for m in re.finditer(substring,string)]

# config_list is readin configuration': corresponding to Strategy C
def strategy_C(pages,config_list): # result will be the parameters that shows in the same description
	f=open("result/raw_result_C",'w')
	content =""
	for app_one in config_list:
		for app_two in config_list:
			if app_one>=app_two:# avoid repeating comparison
				continue
			else:
				print app_one,app_two
				for config_one in config_list[app_one]:
					for config_two in config_list[app_two]:
						if config_two in pages[config_one].split():
							line = config_one+" "+app_one+" "+config_two+" "+app_two+"\n"
							content=content+line
	f.write(content)
	f.close()
	f=open("result/raw_result_C",'r')
	lines = f.readlines()
	lines=list(set(lines))
	f.close()
	f=open("result/raw_result_C",'w')
	for line in lines:
		f.write(line)
	f.close()

def strategy_C_further(filename):# aggregate the parameters that possibly has inter-sw dependency with others for every component
	f=open(filename,'r')
	g=open(filename+"_aggregate",'w')
	my_dict={}
	for line in f:
		line=line.split()#result: conf1,app_1, conf2 and app_2
		key=line[1]
		if key not in my_dict:
			my_dict[key]=[]
		if line[0] not in my_dict[key]:# add unincluded description(p)
			my_dict[key].append(line[0])
			# my_dict[key].append(line[2])
		# else:
		# 	if line[0] not in my_dict[key]:
		# 		my_dict[key].append(line[0])
		# 	if line[2] not in my_dict[key]:
		# 		my_dict[key].append(line[2])
		key=line[3]
		if key not in my_dict:
			my_dict[key]=[]
		if line[2] not in my_dict[key]:# add unincluded description(p)
			my_dict[key].append(line[2])
	for key in my_dict:
		g.write(key+" : "+ str(my_dict[key])+"\n")
	return my_dict			

#TODO:descrition contains keyword
def strategy_D(pages,config_list):
	f=open("result/raw_result_D",'w')
	content =""
	for app_one in config_list:
		for app_two in config_list:
			if app_one>=app_two:# avoid repeating comparison
				continue
			else:
				print app_one,app_two
				for config_one in config_list[app_one]:
					for config_two in config_list[app_two]:
						for keyword in config_two.split('_'):
							if keyword in pages[config_one].split():
								line = config_one+" "+app_one+" "+config_two+" "+keyword+" "+app_two+"\n"
								content=content+line
	f.write(content)
	f.close()
	f=open("result/raw_result_D",'r')
	lines = f.readlines()
	lines=list(set(lines))
	f.close()
	f=open("result/raw_result_D",'w')
	for line in lines:
		f.write(line)
	f.close()

# TODO:description contains keyword
def strategy_E(pages,config_list):
	f=open("result/raw_result_E",'w')
	content =""
	for app_one in config_list:
		for app_two in config_list:
			if app_one>=app_two:# avoid repeating comparison
				continue
			else:
				print app_one,app_two
				for config_one in config_list[app_one]:
						if  app_two in pages[config_one].split():
							line = config_one+" "+app_one+" "+app_two+"\n"
							content=content+line

	f.write(content)
	f.close()
	f=open("result/raw_result_E",'r')
	lines = f.readlines()
	lines=list(set(lines))
	f.close()
	f=open("result/raw_result_E",'w')
	for line in lines:
		f.write(line)
	f.close()

#TODO:description contains application and its parameter name
def strategy_E_further(pages,config_list):
	f=open("result/raw_result_E_further",'w')
	content =""
	for app_one in config_list:
		for app_two in config_list:
			if app_one>=app_two:# avoid repeating comparison
				continue
			else:
				print app_one,app_two
				for config_one in config_list[app_one]:
					for config_two in config_list[app_two]:
						if config_two in pages[config_one].split() and app_two in pages[config_one].split():
							line = config_one+" "+app_one+" "+config_two+" "+app_two+"\n"
							content=content+line

	f.write(content)
	f.close()
	f=open("result/raw_result_E_further",'r')
	lines = f.readlines()
	lines=list(set(lines))
	f.close()
	f=open("result/raw_result_E_further",'w')
	for line in lines:
		f.write(line)
	f.close()

def cos_similarity(vector_one,vector_two):
	s=0.
	for i in range(len(vector_one)):
		s+=vector_one[i]*vector_two[i]
	One=0.
	Two=0.
	for i in range(len(vector_one)):
		One+=vector_one[i]*vector_one[i]
	One=math.sqrt(One)
	for i in range(len(vector_two)):
		Two+=vector_two[i]*vector_two[i]
	Two=math.sqrt(Two)
	return s/(One*Two)
def read_corpus(fname,tokens_only=False):
	with smart_open.smart_open(fname,encoding="iso-8859-1") as f:
		for i, line in enumerate(f):
			if tokens_only:
				yield gensim.utils.simple_preprocess(line.split('**')[1])
			else:
				yield gensim.models.doc2vec.TaggedDocument(gensim.utils.simple_preprocess(line.split('**')[1]),[i])

# seems to find the configuration parameters with the most similar description. 
# process the all the parameters(including all softwares)
# calculate the cosine between every parameter desc
def strategy_F(config_content):
	f=open('result/raw_result_F','w')
	#build and train the models
	train_corpus=[]
	for app in applications:
		train_corpus+=list(read_corpus('../configuration_files/'+app+"/"+app+"_configuration"))
	model=gensim.models.doc2vec.Doc2Vec(vector_size=50,min_count=2,epochs=40)
	model.build_vocab(train_corpus)
	model.train(train_corpus, total_examples=model.corpus_count, epochs=model.epochs)

	#assign inferred vectors
	vectors={}
	for app in applications:
		for (config,content) in config_content[app]:
			vectors[config]=model.infer_vector(gensim.utils.simple_preprocess(content))

	#finding closet top 5 for each
	result={}
	for app_one in applications:
		for app_two in applications:
			if app_one<=app_two:
				continue
			else:
				for (config_one,content_one) in config_content[app_one]:
					for (config_two,content_two) in config_content[app_two]:
						if config_one not in result:
							result[config_one]=[]
						if config_two not in result:
							result[config_two]=[]
						result[config_one].append((config_two,cos_similarity(vectors[config_one],vectors[config_two])))
						result[config_two].append((config_one,cos_similarity(vectors[config_one],vectors[config_two])))
	for config in result:
		result[config].sort(key=lambda tup: tup[1])
	for config in result:
		f.write(config+" : "+str(result[config])+"\n")
	f.close()
	return result

# for every parameter, sort its similar parameter
def strategy_F_further(filename):
	f=open(filename,'r')
	g=open(filename+"_further",'w')
	newresult={}
	for line in f:
		line=line.split(':')
		newresult[line[0]]=[]
		tmp=eval(line[1])
		newresult[line[0]]=tmp[-1:]
	for element in newresult:
		g.write(element+" : "+str(newresult[element])+"\n")
	g.close()
	f.close()
# for every paramter, give its similar parameters that exceeds certain degree
def strategy_F_further_further(filename,threshold):
	f=open(filename,'r')
	g=open(filename+"_further",'w')
	newresult={}
	for line in f:
		line=line.split(':')
		newresult[line[0]]=[]
		tmp=eval(line[1])
		if(tmp[0][1]>=threshold):
			g.write(line[0]+" : "+line[1])
	g.close()
	f.close()
def strategy_F_further_further_further(filename):
	f=open(filename,'r')
	g=open(filename+"_further",'w')
	newresult=[]
	for line in f:
		line=line.split(':')
		tmp=eval(line[1])
		nameone=line[0].strip()
		nametwo=tmp[0][0].strip()
		key_value=""
		if nameone<nametwo:
			key_value=nameone+" "+nametwo
		else:
			key_value=nametwo+" "+nameone
		if key_value not in newresult:
			newresult.append(key_value)
	for element in newresult:
		g.write(element+'\n')
	g.close()
	f.close()
def strategy_value_constraint(pages):
	keywords=["larger", "below", "capped", "less", "lower", "maximum", "fraction", "equal", "smaller", "greater"]
	g=open("result/value_constraint",'w')
	result={}
	for k in keywords:
		result[k]=[]
		for p in pages:
			if k in pages[p].lower():
				result[k].append(p)
	for k in result:
		g.write(k+" "+str(result[k])+"\n")
	g.close() 
pages=readin('description.json')
config_list=get_configuration_parameter()
# strategy_C(pages,config_list)
# strategy_C_further("result/raw_result_C")
# strategy_E(pages,config_list)
# strategy_E_further(pages,config_list)
# strategy_D(pages,config_list)
config_content=get_configuration_content()
strategy_F(config_content)
strategy_F_further("result/raw_result_F")
strategy_F_further_further("result/raw_result_F_further",0.95)
strategy_F_further_further_further("result/raw_result_F_further_further")
strategy_value_constraint(pages)
