import json

applications=['nova','glance','keystone','neutron','cinder','placement']
dict={}
for app in applications:
	f=open('../configuration_files/'+app+"/"+app+"_configuration",'r')
	for line in f:
		line = line.strip()
		line=line.split("**")
		if(len(line)==4):
			dict[line[0].lower()]=line[3].lower()
f.close()
json = json.dumps(dict)
f=open('description.json','w')
f.write(json)
f.close