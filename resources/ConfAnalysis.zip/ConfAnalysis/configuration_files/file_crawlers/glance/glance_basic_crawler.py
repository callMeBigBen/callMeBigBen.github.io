import os
import re
import urllib2
from bs4 import BeautifulSoup

def main():
	link="https://docs.openstack.org/glance/stein/configuration/configuring.html"
	req =  urllib2.Request(link, headers={'User-Agent': 'Mozilla/5.0'})
	page = urllib2.urlopen(req)
	content= page.read()
	content=BeautifulSoup(content,'lxml')
	configurations=content.find_all('dt')
	result=[[],[],[],[]]
	for conf in configurations:
		if(conf.code is not None and conf.code.span is not None):
			name_ = conf.code.span.string
		else:
			name_ = None
		if(conf.dd is not None and conf.dd.p is not None and conf.dd.p.string is not None and 'Optional' in conf.dd.p.string):
			optional_ = True
		else:
			optional_ = False
		if(len(conf.find_all('code'))>1):
			default_ = conf.find_all('code')[1].string
		else:
			default_ = None
		description_ = conf.get_text()
		if(not name_ is None):
			result[0].append(name_)
		else:
			result[0].append('N/A')
		if(optional_):
			result[1].append('Optional')
		else:
			result[1].append('Not Optional')
		if(not default_ is None):
			result[2].append(default_)
		else:
			result[2].append('N/A')
		if(not description_ is None):
			result[3].append(description_)
		else:
			result[3].append('N/A')
	f=open('../../configuration_files/glance/glance_basic_configuration','w')
	for i in range(len(result[0])):
		f.write((result[0][i]+'**'+result[1][i]+'**'+result[2][i]+'**'+result[3][i]+'\n').encode("utf-8"))
	f.close()
main()