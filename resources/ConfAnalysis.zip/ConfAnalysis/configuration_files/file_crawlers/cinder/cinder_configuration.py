import os
import re
import urllib2
from bs4 import BeautifulSoup

def main():
	overall_link = 'https://docs.openstack.org/cinder/stein/configuration/block-storage/volume-drivers.html'
	req =  urllib2.Request(overall_link, headers={'User-Agent': 'Mozilla/5.0'})
	page = urllib2.urlopen(req)
	content= page.read()
	content=BeautifulSoup(content,'lxml')
	wrapper=content.find_all('ul')[7]
	links=[]
	for link in wrapper.find_all('li'):
		links.append('https://docs.openstack.org/cinder/stein/configuration/block-storage/'+link.find('a')['href'])
	result=[[],[],[],[]]
	for link in links:
		print(link)
		if link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/dell-emc-vnx-driver.html' :
			continue
		if  link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/huawei-storage-driver.html':
			continue
		if link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/ibm-flashsystem-volume-driver.html':
			continue
		if link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/ibm-gpfs-volume-driver.html':
			continue
		if link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/ibm-storage-volume-driver.html':
			continue
		if link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/ibm-storwize-svc-driver.html':
			continue

		# if link == 'https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/nexentaedge-driver.html':
		# 	continue
		# if link == 'https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/nexentastor4-driver.html':
		# 	continue
		# if link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/nexentastor5-driver.html':
		# 	continue
		# if link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/prophetstor-dpl-driver.html':
		# 	continue
		# if link == 'https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/pure-storage-driver.html':
		# 	continue
		req =  urllib2.Request(link, headers={'User-Agent': 'Mozilla/5.0'})
		page = urllib2.urlopen(req)
		content= page.read()
		content=BeautifulSoup(content,'lxml')
		wrappers=content.find_all('tbody')
		if link =='https://docs.openstack.org/cinder/stein/configuration/block-storage/drivers/netapp-volume-driver.html':
			wrappers = wrappers[:2]
		for wrapper in wrappers:
			if wrapper is not None:
				infos=wrapper.find_all('tr')
			else:
				continue
			for info in infos:
				if info.td.code is not None:
					name_ = info.find('td').find('code').span.string
				else:
					continue
				print(name_)
				if len(info.td.find_all('span'))>1:
					default_ = info.td.find_all('span')[1].string
				rest_ = info.find_all('td')[1].get_text()
				type_ = rest_[1:rest_.find(' ')-1]
				description_ = rest_[rest_.find(' ')+1:]
				if(not name_ is None):
					result[0].append(name_)
				else:
					result[0].append('N/A')
				if(not type_ is None):
					result[1].append(type_)
				else:
					result[1].append('N/A')
				if(not default_ is None):
					result[2].append(default_)
				else:
					result[2].append('N/A')
				if(not description_ is None):
					result[3].append(description_)
				else:
					result[3].append('N/A')
	f=open('../../configuration_files/cinder/cinder_configuration','w')
	for i in range(len(result[0])):
		f.write(('##'+result[0][i]+'**'+result[1][i]+'**'+result[2][i]+'**'+result[3][i]+'\n').encode("utf-8"))
	f.close()
main()