import os
import re
import urllib2
from bs4 import BeautifulSoup

def main():
	link="https://docs.openstack.org/nova/stein/configuration/config.html"
	req =  urllib2.Request(link, headers={'User-Agent': 'Mozilla/5.0'})
	page = urllib2.urlopen(req)
	content= page.read()
	content=BeautifulSoup(content,'lxml')
	configurations=content.find_all(class_='option')
	result=[[],[],[],[]]
	for conf in configurations:
		name_ = conf.find('code', class_='descname').string
		type_ = conf.find('td',class_='field-body').string
		default_ = conf.find('span',class_='pre').string
		description_ = conf.find('p').string
		if(not name_ is None):
			result[0].append(name_)
		else:
			result[0].append('N/A')
		if(not type_ is None):
			result[1].append(type_)
		else:
			result[1].append('N/A')
		if(not default_ is None):
			result[2].append(default_)
		else:
			result[2].append('N/A')
		if(not description_ is None):
			result[3].append(description_)
		else:
			result[3].append('N/A')
	f=open('../../configuration_files/nova/nova_configuration','w')
	for i in range(len(result[0])):
		f.write(('##'+result[0][i]+'**'+result[1][i]+'**'+result[2][i]+'**'+result[3][i]+'\n').encode("utf-8"))
	f.close()
main()