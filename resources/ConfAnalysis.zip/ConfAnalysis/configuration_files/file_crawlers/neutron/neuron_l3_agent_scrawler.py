import os
import re
import urllib2
from bs4 import BeautifulSoup

def main():
	link="https://docs.openstack.org/neutron/pike/configuration/l3-agent.html"
	req =  urllib2.Request(link, headers={'User-Agent': 'Mozilla/5.0'})
	page = urllib2.urlopen(req)
	content= page.read()
	content=BeautifulSoup(content,'lxml')
	names=content.find_all('code',class_='descname')
	infos=content.find_all('dl',class_='option')
	result=[[],[],[],[]]
	for name in names:
		name_ = name.string
		if(not name_ is None):
			result[0].append(name_)
		else:
			result[0].append('N/A')
	for info in infos:
		type_ = info.find_all('td')[0].string
		default_ = info.find_all('td')[1].string
		description_list = info.find_all('p')
		description_ = ''
		for p in description_list:
			if p is not None and p.string is not None:
				description_+=p.string+' '
		if(not type_ is None):
			result[1].append(type_)
		else:
			result[1].append('N/A')
		if(not default_ is None):
			result[2].append(default_)
		else:
			result[2].append('N/A')
		if(not description_ is None):
			result[3].append(description_)
		else:
			result[3].append('N/A')
	f=open('../../configuration_files/neutron/neutron_l3_agent_configuration','w')
	for i in range(len(result[0])):
		f.write(('##'+result[0][i]+'**'+result[1][i]+'**'+result[2][i]+'**'+result[3][i]+'\n').encode("utf-8"))
	f.close()
main()