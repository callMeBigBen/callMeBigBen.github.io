## Formatting of the files: the infos of every configuration parameter has 3 '**' to separate the 4 fields of a parameter shown as below:
- name
- type
- default value
- description

##eg: ##ParameterA**Boolean**False**This is a parameter for test

