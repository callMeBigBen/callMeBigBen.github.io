import sys
reload(sys)
sys.setdefaultencoding('utf-8')

import os
import os.path
import time
time1=time.time()


def MergeTxt(filepath,outfile):
    k = open(filepath+outfile, 'a+')
    for parent, dirnames, filenames in os.walk(filepath):
        for filepath in filenames:
            txtPath = os.path.join(parent, filepath) 
            f = open(txtPath)
            k.write(f.read()+"\n")

    k.close()

    print "finished"


if __name__ == '__main__':
    filepath="/home/shawn/Desktop/ConfAnalysis/configuration_files/neutron/"
    outfile="neutron_configuration"
    MergeTxt(filepath,outfile)
    time2 = time.time()
