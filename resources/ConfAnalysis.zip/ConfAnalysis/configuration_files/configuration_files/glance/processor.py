import os
import sys
import io

reload(sys)
sys.setdefaultencoding('utf-8')

def pro():
	config_list=[]
	content_after = ""
	f=open('glance_configuration','r+')
	content = f.read()
	lines = content.split('##')
	for line in lines:
		line = line.replace('\n','')
		line = line.replace('\r','')
		line2 = line.split("**")
		if(len(line2)==4):
			line2[3].replace(line2[0],"")
			line2[3].replace(line2[1],"")
			line2[3].replace(line2[2],"")
			line = line2[0]+"**"+line2[1]+"**"+line2[2]+"**"+line2[3]+"\n"
			content_after = content_after+line


	# lines = content.splitlines()
	# content.replace('\n','')
	# content.replace('\r','')
	
	# content = ''
	# for line in lines:
	# 	content = content +line
	# f.close()
	# content.replace("##",'\r\n##')
	# for line in f:
	# 	line=line.split("**")
	# 	config_list.append(line[0]+"**N/A**"+line[1]+"**"+line[2])
	f.close()

	f=open("glance_configuration",'w')
	f.write(content_after)

	f.close()
	print('done')

pro()
