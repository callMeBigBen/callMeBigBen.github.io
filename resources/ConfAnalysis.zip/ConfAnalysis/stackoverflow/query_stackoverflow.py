def process(infile,outfile,datasources):
    source=open(datasources,'r')
    fin=open(infile,'r')
    fou=open(outfile,'w')
    pairs=[]
    for line in fin:
        configs = line.split()
        pairs.append(configs)
    for f in source:
        for pair in pairs:
            content=""
            flag=True
            for ele in pair:
                if ele not in f:
                    flag=False
                    break
                content+=ele+" "
            if flag:
               fou.write(content+":"+f+"\n")
    fou.close()
process("inter-cases-for-checking.txt","inter-cases-StackOverflow.txt","Posts.xml")

