
f=open("../../Posts.xml",'r')
f_two=open("cross_application_configuration.txt",'w')
#applications=['mysql','php','solr','kafka']
applications=['drill','hdfs','hive','mapreduce','pig','spark','storm','yarn','hbase']
configurations={}
fopens={}
for app in applications:
   configurations[app]=[]
   f_three=open('../'+app+'-configuration','r')
   for line in f_three:
      line=line.split("**")[0].strip()
      configurations[app].append(line)
   f_tmp=open("crawl_"+app+"_configuration.txt",'r')
   fopens[app]=f_tmp
for app_one in applications:
   print app_one
   for line in fopens[app_one]:
      for app_two in applications:
         if app_one==app_two:
           continue
         else:
           for config in configurations[app_two]:
               if config in line and 'ParentId' in line:
                     f_two.write(app_two+":"+config+" "+app_one+':'+line)
f_two.close()
       
