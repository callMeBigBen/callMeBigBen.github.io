f=open("ranked_result_with_only_comments_cleaner.txt",'r')
g=open("need_to_read.txt",'w')
def number(text):
	result=""
	for i in range(len(text)):
		if text[i]<='9' and text[i]>='0':
			result+=text[i]
	return result
dic={}
for line in f:
	line=line.split()
	for i in range(3,len(line)):
		num=number(line[i])
		print num
		dic[num]=1
for ele in dic:
	g.write(ele+"\n")
g.close()
f.close()