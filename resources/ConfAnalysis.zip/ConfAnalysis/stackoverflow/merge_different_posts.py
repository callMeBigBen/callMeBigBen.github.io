def process(infile):
    Input=open(infile,"r")
    output=open(infile[:-4]+"_megred.txt","w")
    final_result={}
    for line in Input:
       if line.strip()=="":
          continue
       content=line.split()
       key=min(content[0],content[1])+" "+max(content[0],content[1])
       ind=content[4][4:-1]
       if "ParentId" in line:
       	  ind=content[6][10:-1]
       if key in final_result:
       	   if ind not in final_result[key]:
       	   	  final_result[key].append(ind)
       else:
       	  final_result[key]=[]
       	  final_result[key].append(ind)
    for key in final_result:
    	output.write(str(key)+" : "+str(final_result[key])+"\n")
process("inter-cases-StackOverflow.txt")

