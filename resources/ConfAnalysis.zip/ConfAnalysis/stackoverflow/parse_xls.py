import pandas as pd
def process(infile,outfile):
    xls = pd.ExcelFile(infile)
    output = open (outfile,'w')
    sheetX = xls.parse(0)
    column_A = sheetX['Configuration Parameter A']
    column_B = sheetX['Configuration Parameter B( ,C and more)']
    for i in range(len(column_A)):
        if str(column_A[i])=='nan' :
            break
        else:
            output.write(column_A[i].strip()+" "+column_B[i].strip()+"\n")
    output.close()
process("../../Teng\'s_work/Doc/intra-sw dependency.xlsx","intra-cases-for-checking.txt")

