f=open("../../Posts.xml",'r')
applications=['drill','hdfs','hive','kafka','mapreduce','mysql','php','pig','solr','spark','storm','yarn','hbase']
fileopens={}
for app in applications:
   filename="crawl_"+app+".txt"
   f_two=open(filename,'w')
   fileopens[app]=f_two
for line in f:
   for app in applications:
      if app in line.lower():
           fileopens[app].write(line)
for app in applications:
   fileopens[app].close()

