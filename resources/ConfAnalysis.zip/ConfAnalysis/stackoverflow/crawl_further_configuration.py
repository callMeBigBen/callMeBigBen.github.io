applications=['drill','hdfs','hive','kafka','mapreduce','mysql','php','pig','solr','spark','storm','yarn','hbase']
for app in applications:
    filename='crawl_'+app+'_configuration.txt'
    f=open(filename,'w')
    f_two=open('crawl_'+app+".txt",'r')
    f_three=open('../'+app+"-configuration",'r')
    configs=[]
    for line in f_three:
       line=line.split("**")[0].strip()
       configs.append(line)
    print app, len(configs)
    exist={}
    for line in f_two:
       for config in configs:
           if config in line:
                  f.write(config+' '+line)
                  if config in exist:
                       continue
                  else:
                      exist[config]=1
    print len(exist)
    f.close()
    f_two.close()
    f_three.close()
